#ifndef DEKLARACJE_H_INCLUDED
#define DEKLARACJE_H_INCLUDED


#define maxstring 8
#define spiecesNumber 7

//Czestotliwosci rozmnazania sie zwierzat wyrazone w miesiacach
#define KONIE_F 12
#define OSLY_F 12
#define MULY_F 24
#define JASTRZEBIE_F 6
#define MYSZOLOWY_F 4
#define MYSZY_F 1
#define ZAJACE_F 2

#define PARAMSNUMBER 6

using namespace std;
enum ANIMALS { KON, OSIOL, MUL, JASTRZAB, MYSZOLOW, MYSZ, ZAJAC };

#endif // DEKLARACJE_H_INCLUDED
